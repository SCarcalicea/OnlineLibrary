package booksService;

public class Book {

    private String filePath;
    private String title;
    private String publisher;
    private String author;
    private String owner;
    private String category;

    public Book() {
        
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the publisher
     */
    public String getPublisher() {
        return publisher;
    }

    /**
     * @param publisher the publisher to set
     */
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    /**
     * @param owner the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }
    
    /**
     * This method will return a string representation of the values that 
     * are going to be inserted into the data base. Like in the example below
     * 
     * @return - ('testing2','testing2','testing2','testing2','testing2','testing2')
     */
    public String toString() {
        StringBuffer buf = new StringBuffer("('");
        String space = "','";
        String end = "')";
        buf.append(this.getFilePath()).append(space)
                .append(this.getTitle()).append(space)
                .append(this.getPublisher()).append(space)
                .append(this.getAuthor()).append(space)
                .append(this.getOwner()).append(space)
                .append(this.getCategory()).append(end);
        
        return buf.toString();
    }
}
