package validation.view;

import javax.faces.bean.ManagedBean;

/**
 *
 * @author Cojocaru
 */
@ManagedBean
public class RemoteCommandView {
    
    public String sendRedirect() {
        return "/login.xhtml?faces-redirect=true";
    }
}
