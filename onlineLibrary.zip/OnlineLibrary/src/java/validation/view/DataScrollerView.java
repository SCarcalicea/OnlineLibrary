package validation.view;

import booksService.Book;
import booksService.BookService;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
 
@ManagedBean (name = "dataScrollerView")
@ViewScoped
public class DataScrollerView implements Serializable {
     
    private List<Book> books;
    private static final long serialVersionUID = 1L;
    private Book selectedBook;
         
    @ManagedProperty("#{bookService}")
    private BookService service;
     
    @PostConstruct
    public void init() {
        try {
            books = service.createBooks(10);
        } catch (SQLException e) {
            // Do nothing for now
        }
    }
 
    public List<Book> getBooks() {
        return books;
    }
 
    public void setService(BookService service) {
        this.service = service;
    }

    /**
     * @return the selectedBook
     */
    public Book getSelectedBook() {
        return selectedBook;
    }

    /**
     * @param selectedBook the selectedBook to set
     */
    public void setSelectedBook(Book selectedBook) {
        this.selectedBook = selectedBook;
    }
}