package validation.view;

import constants.DatabaseConst;
import gateway.LogInGateway;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 *
 * @author Cojocaru
 */
@ManagedBean
@ApplicationScoped
public class LoginView {

    private String username;
    private String password;
    public static Connection con;
    private boolean admin;

    public String getUserName() {
        return username;
    }

    public void setUserName(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String check() {
        try {
            //LogInGateway login = new LogInGateway("admin", "testing", true);//Debug only
            LogInGateway login = new LogInGateway(username, password, admin);
            if (login.checkPassword(LoginView.con)) {
                // Log in successfull
                if (login.isAdmin()) { // Is Admin
                    sendRedirect();
                    return "";
                } else { // NonAdmin
                    sendRedirect();
                    return "";
                }
            } else {
                // Error case
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "User Name/password are incorect!!!", ""));
                return "";
            }
        } catch (SQLException | IOException ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR!!!", ""));
            return "";
        }
    }

    /** 
     * Redirect to index page
     * 
     * @throws IOException 
     */
    public void sendRedirect() throws IOException{
        ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
        String contextPath = context.getRequestContextPath();
        context.redirect(contextPath + "/faces/index.xhtml?faces-redirect=true");
    }
    

    public String create() {
        try {
            LogInGateway login = new LogInGateway(username, password, admin);
            if (login.createNewUser(LoginView.con)) {
                // User is created
                FacesContext context = FacesContext.getCurrentInstance();
                if (getAdmin()) {
                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Administrator created successfully!!!", ""));
                } else {
                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "User created successfully!!!", ""));
                }

                return "";
            } else {
                // Error
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR!!!", ""));
                return "";
            }
        } catch (SQLException e) {
            // Error
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR!!!", ""));
            return "";
        }
    }

    public boolean connect() {
        if (LoginView.con == null) {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
                LoginView.con = DriverManager.getConnection(DatabaseConst.JDBC_URL, DatabaseConst.DB_USER_NAME, DatabaseConst.DB_PASSWORD);
                /* Note use' / 'and not' \'  The url above will be different in your system*/
                if (LoginView.con != null) {
                    return true; // Connected
                } else {
                    return false; // Cannot conect
                }
            } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException err) {
                return false;
            }
        } else {
            return true;
        }
    }

    public static boolean disconnect() {
        if (LoginView.con != null) {
            try {
                LoginView.con.close();
                LoginView.con = null;
                return true;
            } catch (SQLException ex) {
                return false;
            }
        }
        return false;
    }

    /**
     * @return the admin
     */
    public boolean getAdmin() {
        return admin;
    }

    /**
     * @param admin the admin to set
     */
    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
}
