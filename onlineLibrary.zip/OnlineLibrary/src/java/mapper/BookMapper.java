package mapper;

import constants.DatabaseConst;

/**
 * Mapper class for books table
 * 
 * @author Cojocaru
 */
public class BookMapper {
    
    private static String filePath = DatabaseConst.BOOK_PATH;
    private static String title = DatabaseConst.BOOK_TITLE;
    private static String publisher = DatabaseConst.BOOK_PUBLISHER;
    private static String author = DatabaseConst.BOOK_AUTHOR;
    private static String owner = DatabaseConst.BOOK_OWNER;
    private static String cat = DatabaseConst.BOOK_CATEGORY;
    private static String tableName = DatabaseConst.TABLE_NAME_BOOK;

    /**
     * @return the filePath
     */
    public static String getFilePath() {
        return filePath;
    }

    /**
     * @return the title
     */
    public static String getTitle() {
        return title;
    }

    /**
     * @return the publisher
     */
    public static String getPublisher() {
        return publisher;
    }

    /**
     * @return the author
     */
    public static String getAuthor() {
        return author;
    }

    /**
     * @return the owner
     */
    public static String getOwner() {
        return owner;
    }

    /**
     * @return the cat
     */
    public static String getCat() {
        return cat;
    }

    /**
     * @return the tableName
     */
    public static String getTableName() {
        return tableName;
    }
    
    
}
