package constants;

/**
 * This class holds all of the constants needed in 
 * OnlineLibrary project
 * 
 * @author Cojocaru
 */
public class DatabaseConst {
    
    // Database name and columns names (Table users)
    public static final String TABLE_NAME = " Testing.USERS ";
    public static final String USERS_TABLE_COLUMN = "USERS.ID";
    public static final String PASS_TABLE_COLUMN = "USERS.PASS";
    public static final String ADMIN_TABLE_COLUMN = "USERS.\"ADMIN\"";
    
    // Database name and columns names (Table books)
    public static final String TABLE_NAME_BOOK = " Testing.BOOKS ";
    public static final String BOOK_PATH = "filepath";
    public static final String BOOK_TITLE = "title";
    public static final String BOOK_PUBLISHER = "editura";
    public static final String BOOK_AUTHOR = "autor";
    public static final String BOOK_OWNER = "owner";
    public static final String BOOK_CATEGORY = "category";
    
    // Data base details
    public static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    public static final String JDBC_URL = "jdbc:derby://localhost/testing";
    public static final String DB_USER_NAME = "testing";
    public static final String DB_PASSWORD = "admin";
}
