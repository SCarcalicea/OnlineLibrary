package gateway;

import booksService.Book;
import constants.SQLConst;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mapper.BookMapper;

/**
 * 
 * @author Cojocaru
 */
public class BookGateway {
    
    private final String InsertIntoSQL = SQLConst.INSERT_INTO + BookMapper.getTableName() + SQLConst.VALUES;
    private final String SelectAllSQL = SQLConst.SELECT + " * " + SQLConst.FROM + BookMapper.getTableName();
    private static String DeleteEntrySQL = SQLConst.DELETE + SQLConst.FROM + BookMapper.getTableName() + SQLConst.WHERE + getCondition();
    private static String UpdateFieldSQL = SQLConst.UPDATE + BookMapper.getTableName() + SQLConst.SET + getColumnsToBeUpdated() + SQLConst.WHERE + getCondition();
    private static String columnsToBeUpdated = "";
    private static String condition = "";
    private Statement stmt = null;
    
    public BookGateway(String columnsToBeUpdated, String condition) {
        this.columnsToBeUpdated = columnsToBeUpdated;
        this.condition = condition;
    }
    
    public List<Book> getAllBooks(Connection con) throws SQLException {
        stmt = con.createStatement();
        ResultSet result = stmt.executeQuery(SelectAllSQL);
        List<Book> returnList = new ArrayList<>();
        while (result.next()) {
            Book book = new Book();
            book.setFilePath(result.getString(1));
            book.setTitle(result.getString(2));
            book.setPublisher(result.getString(3));
            book.setAuthor(result.getString(4));
            book.setOwner(result.getString(5));
            book.setCategory(result.getString(6));
            returnList.add(book);
        }
        return returnList;
    }
    
    public boolean addBook(Connection con, Book book) throws SQLException{
        stmt = con.createStatement();
        int rows = stmt.executeUpdate(InsertIntoSQL + book.toString());
        if (rows == 1) {
            return true;
        } else {
            return false;   
        }
    }
    
    public boolean deleteBook(Connection con) throws SQLException{
        stmt = con.createStatement();
        int rows = stmt.executeUpdate(DeleteEntrySQL);
        if (rows == 1) {
            return true;
        } else {
            return false;   
        }
    }
    
    public boolean updateBook(Connection con) throws SQLException{
        stmt = con.createStatement();
        int rows = stmt.executeUpdate(UpdateFieldSQL);
        if (rows == 1) {
            return true;
        } else {
            return false;   
        }
    }
    
    /**
     * @return the columnsToBeUpdated
     */
    public static String getColumnsToBeUpdated() {
        return columnsToBeUpdated;
    }

    /**
     * @param aColumnsToBeUpdated the columnsToBeUpdated to set
     */
    public static void setColumnsToBeUpdated(String aColumnsToBeUpdated) {
        columnsToBeUpdated = aColumnsToBeUpdated;
        UpdateFieldSQL = SQLConst.UPDATE + BookMapper.getTableName() + SQLConst.SET + getColumnsToBeUpdated() + SQLConst.WHERE + getCondition();
    }

    /**
     * @return the condition
     */
    public static String getCondition() {
        return condition;
    }

    /**
     * @param aCondition the condition to set
     */
    public static void setCondition(String aCondition) {
        condition = aCondition;
        UpdateFieldSQL = SQLConst.UPDATE + BookMapper.getTableName() + SQLConst.SET + getColumnsToBeUpdated() + SQLConst.WHERE + getCondition();
        DeleteEntrySQL = SQLConst.DELETE + SQLConst.FROM + BookMapper.getTableName() + SQLConst.WHERE + getCondition();
    }
}
