package gateway;

import constants.SQLConst;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import mapper.LogInMapper;

/**
 * 
 * @author Cojocaru
 */
public class LogInGateway {
    
    private final String CreateSQLStatement = SQLConst.INSERT_INTO + LogInMapper.getTableName() + SQLConst.VALUES;
    private final String CheckSQLStatement = SQLConst.SELECT + LogInMapper.getPassword() + ", " + LogInMapper.getAdmin()  + SQLConst.FROM + LogInMapper.getTableName() + SQLConst.WHERE + LogInMapper.getUser() + "=";
    private String user = "";
    private String password = "";
    private Statement stmt = null;
    private boolean admin = false;
    
    public LogInGateway(String user, String password, boolean isAdmin) {
        this.user = user;
        this.password = password;
        this.admin = isAdmin;
    }
     
    public boolean createNewUser(Connection con) throws SQLException {
        stmt = con.createStatement();
        int rows = stmt.executeUpdate(CreateSQLStatement + "('" + user + "', '" + password +  "', '" + admin + "')");
        if(rows == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean checkPassword(Connection con) throws SQLException {
        stmt = con.createStatement();
        ResultSet result = stmt.executeQuery(CheckSQLStatement + "'" + user + "'");
        if (result.next()) {
            String dbPass = result.getString(1).trim();
            this.setAdmin(result.getBoolean(2));
            if (dbPass.equalsIgnoreCase(password)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * @return the admin
     */
    public boolean isAdmin() {
        return admin;
    }

    /**
     * @param admin the admin to set
     */
    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
    
}
